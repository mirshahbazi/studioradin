const String baseUrl                                                            = 'https://renewing-hawk-97.hasura.app/v1/graphql';
const String adminSecret                                                        = 'Hapoooli@20290';
const String userId                                                             = 'c9bb44da-83e3-f02f-f3d0-b99e99367195'; //brad pit
const String userId2                                                             = 'c7179106-2315-4053-b2d0-bb25c15b7a36';

// const String userId                                                             = '880ac5de-51ec-44e5-b258-a4b1acb6410a'; //amin
const Map<String, String> header = {
  'content-type': 'application/json',
  'x-hasura-admin-secret': adminSecret,
};
