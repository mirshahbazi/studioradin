const String appName                                                            ='استدیو رادین';
const String appPersianFont                                                     ='Dana';
const double bottomBarRound                                                     =16.0;