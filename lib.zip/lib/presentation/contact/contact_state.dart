class ContactState {
  ContactState() {
    ///Initialize variables
  }
}
