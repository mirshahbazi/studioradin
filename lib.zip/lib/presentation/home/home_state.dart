class HomeState {
  HomeState() {
    ///Initialize variables
  }
}
