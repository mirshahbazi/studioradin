class SplashState {
  SplashState() {
    ///Initialize variables
  }
}
