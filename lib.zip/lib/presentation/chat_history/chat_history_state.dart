class ChatHistoryState {
  ChatHistoryState() {
    ///Initialize variables
  }
}
