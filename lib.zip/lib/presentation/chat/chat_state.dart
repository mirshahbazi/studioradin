class ChatState {
  ChatState() {
    ///Initialize variables
  }
}
