class SettingState {
  SettingState() {
    ///Initialize variables
  }
}
