import 'package:get/get.dart';

import 'call_state.dart';

class CallLogic extends GetxController {
  final CallState state = CallState();

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
  }
}
