class CallState {
  CallState() {
    ///Initialize variables
  }
}
